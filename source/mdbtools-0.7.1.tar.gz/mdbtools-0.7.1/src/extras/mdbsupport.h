
void dump_int (int i);
void dump_long (long l);
void dump_string (char *s);
