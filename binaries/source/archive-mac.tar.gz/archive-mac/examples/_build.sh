#!/bin/bash

if [ "$1" = "" ];
then
  echo "Usage: ./_build.sh <example-name> [<build-options>]"
  echo "Or:    ./_build.sh all [<build-options>]"
  exit
fi
    
if [ "$1" = "all" ];
then
  e="fib karatsuba tutorial"
else
  e=$1
fi

if [ "$2" != "" ];
then
  OPT=$2
else
  OPT="-O3"
fi


CLANG_HOME=`xcrun -find clang`
CLANG_HOME=`dirname $CLANG_HOME`
BUILD_HOME=`pwd`

BUILD_FLAGS="-v -fcilkplus -I$BUILD_HOME/../lib -L$BUILD_HOME/../lib -ldl -march=native $OPT"
    
export DYLD_LIBRARY_PATH="$BUILD_HOME/../lib:$DYLD_LIBRARY_PATH"
export PATH="$BUILD_HOME/../bin:$PATH"
export CXX=clang++
export CC=clang
export CXXFLAGS=$BUILD_FLAGS
export CFLAGS=$BUILD_FLAGS

echo Examples building... >build.log

for example in $e
do
  cd $example
  if [ -f "_build.sh" ]; 
  then
    ./_clean.sh 2>&1 | cat >>../build.log
    ./_build.sh 2>&1 | cat >>../build.log
  fi
  if [ -f "Makefile" ]; 
  then
    make clean 2>&1 | cat >>../build.log
    make build 2>&1 | cat >>../build.log
  fi
  cd ..
done

