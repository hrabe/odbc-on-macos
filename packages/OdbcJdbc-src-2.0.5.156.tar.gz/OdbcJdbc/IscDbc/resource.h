// Used by IscDbc.rc
//
